//Função de soma

const soma = function(num1,num2){
    return(num1 + num2);
}

const subtracao = function(num1,num2){
    return(num1 - num2);
}

const multiplicacao = function(num1,num2){
    return(num1 * num2);
}

const divisao = function(num1,num2){
    return(num1 / num2);
} 